export class Phone{
	id: number;
	name: string;
	
}
