"use strict";
var Phone = (function () {
    function Phone() {
    }
    return Phone;
}());
exports.Phone = Phone;
//# sourceMappingURL=phone.js.map